---
name: visual-design-polish
description: Improve frontend visual design with subject-specific direction, hierarchy, typography, spacing, palette, density, responsive screenshot QA, and anti-generic UI critique.
---

# Visual Design Polish

Use this skill when a frontend screen works but feels generic, visually weak, poorly prioritized, too crowded, too empty, or mismatched to the product's subject and audience. Do not use it for pure Tailwind class cleanup, backend work, accessibility-only audits, or design-system extraction unless the main request is visual direction and polish.

## Decision Rules

- Start from the product, audience, and screen job. A design direction must be specific enough that it would not fit a random SaaS page.
- Make one memorable visual move and keep the rest disciplined.
- Prefer hierarchy, readability, density, and subject fit over decoration.
- Treat screenshots as evidence. Visual claims should refer to what is visible at real viewports.
- Avoid generic AI-layout defaults: purple-blue gradients, floating blobs, nested cards, random icon grids, vague SaaS copy, one-note palettes, and ornamental shadows.
- Treat current model house styles as calibration data, not inspiration. Warm cream backgrounds with serif display type and terracotta accents can be appropriate for editorial or hospitality work, but they are a default failure for dashboards, developer tools, finance, healthcare, and dense operational UIs unless the brief justifies them.
- If the brief is open-ended and the user needs taste direction, sketch 3 distinct directions before building. If the user asked for direct implementation, choose the strongest direction, state the visual thesis, and proceed.
- Preserve existing product conventions unless the task explicitly asks for a new direction.
- Copy, data density, and imagery are design materials. Generic placeholder SaaS copy can make a good layout feel AI-generated.

## Workflow

1. Capture the design brief: screen, audience, primary job, current complaint, implementation surface, and available screenshots.
2. Inspect local visual language: adjacent pages, tokens, type scale, spacing, buttons, cards, forms, empty states, and brand cues.
3. Write a compact visual thesis:
   - subject and audience;
   - hierarchy target;
   - palette role;
   - typography role;
   - density target;
   - one signature move;
   - one default aesthetic you are explicitly rejecting.
4. Critique the current UI against the thesis:
   - first-viewport priority;
   - typography scale and weight;
   - spacing rhythm and grouping;
   - contrast and palette discipline;
   - content density;
   - imagery or icon relevance;
   - copy specificity and product vocabulary;
   - whether decorative devices encode real information;
   - responsive fit.
5. Run the anti-generic check: would the same page work unchanged for a random analytics SaaS, portfolio, or AI startup? If yes, revise palette, type treatment, layout structure, content, or the signature move until at least two choices are subject-specific.
6. Remove or reduce generic decoration before adding new decoration.
7. Make scoped implementation changes using local components, tokens, and CSS/Tailwind conventions.
8. Verify with before/after screenshots or state the exact viewport checks still needed.

## Anti-Generic Quality Gates

- The visual direction should name a concrete source from the product world: material, instrument, artifact, workflow, environment, audience, or data shape.
- The signature move should be useful or meaningful, not a sticker. Examples: a manga library can use shelf/spine rhythm; a trading tool can use order-book density; a healthcare portal can use calm clinical hierarchy rather than neon gradients.
- Typography should have roles, not just font names: display, body, utility/data, labels, and numbers where relevant.
- Color should have semantic jobs: surface, text, muted, accent, success/warning/danger, focus, data series. Do not add accent colors that do not guide attention.
- Ornament should earn its space. Delete background blobs, glows, grids, and icon clusters when they do not improve comprehension, hierarchy, or brand fit.
- Keep the quality floor: WCAG AA contrast where practical, visible keyboard focus, stable controls, mobile fit, and reduced-motion support.

## Validation

- Check mobile narrow, common mobile, and desktop viewports when possible.
- Ensure no text/control overlap, horizontal scroll, or focus-state loss.
- Verify long titles, empty states, loading states, and primary actions still work visually.
- Check normal text contrast against 4.5:1 and large text or meaningful UI graphics against 3:1 when colors changed.
- Check pointer targets around 24x24 CSS pixels or adequate spacing for compact interfaces.
- If the change is subjective, explain why it fits this product better than the previous direction.

## Output Contract

- Visual thesis first.
- Evidence inspected: screenshots, viewports, local components, tokens, or missing.
- Top visual issues ordered by user impact.
- Changes made or recommended.
- Viewports/states verified.
- Remaining subjective risk or missing screenshots.

import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { auditSkill } from "../audit/index.ts";
import { upsertInstalledSkill } from "../lockfile/index.ts";
import type { InstallPlan, RegistrySkill } from "../types.ts";
import type { AgentAdapter, InstallInput } from "./types.ts";

const repoSkillBase = ".agents/skills";

const slugFromSkill = (skill: RegistrySkill) => {
  const slug = skill.manifest.name.replace(/[^a-z0-9._-]+/gi, "-").toLowerCase();
  if (!/^[a-z0-9][a-z0-9._-]*$/.test(slug) || slug === "." || slug === ".." || slug.includes("..")) {
    throw new Error(`Invalid install slug for ${skill.manifest.id}: ${skill.manifest.name}`);
  }
  return slug;
};

const installPath = (projectRoot: string, skill: RegistrySkill, scope: InstallInput["scope"]) => {
  if (scope !== "repo") {
    throw new Error("Only repo scope is implemented for the MVP installer.");
  }
  const base = path.resolve(projectRoot, repoSkillBase);
  const target = path.resolve(base, slugFromSkill(skill));
  if (target !== base && !target.startsWith(`${base}${path.sep}`)) {
    throw new Error(`Install path escaped repo skill directory for ${skill.manifest.id}.`);
  }
  return target;
};

export const codexAdapter: AgentAdapter = {
  id: "codex",
  async planInstall(skill: RegistrySkill, input: InstallInput): Promise<InstallPlan> {
    const target = installPath(input.projectRoot, skill, input.scope);
    return {
      skillId: skill.manifest.id,
      targetAgent: input.targetAgent,
      scope: input.scope,
      dryRun: input.dryRun,
      writes: [path.join(target, "SKILL.md"), path.join(target, "skill.manifest.json")],
      lockfileUpdates: [path.join(input.projectRoot, "skillranger.lock.json")],
      warnings: input.scope === "repo" ? [] : ["Only repo scope is supported in MVP."]
    };
  },
  async applyInstall(skill: RegistrySkill, input: InstallInput): Promise<InstallPlan> {
    const plan = await this.planInstall(skill, input);
    if (input.dryRun) return plan;

    const audit = await auditSkill(skill);
    if (audit.riskLevel === "block") {
      throw new Error(`Blocked install for ${skill.manifest.id}: audit risk is block.`);
    }

    const target = installPath(input.projectRoot, skill, input.scope);
    await mkdir(target, { recursive: true });
    await writeFile(path.join(target, "SKILL.md"), await readFile(skill.skillPath, "utf8"));
    await writeFile(path.join(target, "skill.manifest.json"), `${JSON.stringify(skill.manifest, null, 2)}\n`);
    await upsertInstalledSkill(input.projectRoot, skill, {
      targetAgent: input.targetAgent,
      scope: input.scope,
      installedPath: path.relative(input.projectRoot, target),
      audit
    });
    return plan;
  }
};

export const genericAgentSkillsAdapter = {
  ...codexAdapter,
  id: "generic-agent-skills"
} satisfies AgentAdapter;

export const getAdapter = (targetAgent: string): AgentAdapter => {
  if (targetAgent === "codex") return codexAdapter;
  if (targetAgent === "generic-agent-skills") return genericAgentSkillsAdapter;
  throw new Error(`Unsupported target agent for MVP: ${targetAgent}`);
};

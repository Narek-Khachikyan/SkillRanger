import type { InstallPlan, InstallScope, RegistrySkill } from "../types.ts";

export type InstallInput = {
  projectRoot: string;
  targetAgent: string;
  scope: InstallScope;
  dryRun: boolean;
};

export type AgentAdapter = {
  id: string;
  planInstall(skill: RegistrySkill, input: InstallInput): Promise<InstallPlan>;
  applyInstall(skill: RegistrySkill, input: InstallInput): Promise<InstallPlan>;
};

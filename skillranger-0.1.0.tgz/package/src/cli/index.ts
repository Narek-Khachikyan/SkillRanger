#!/usr/bin/env node
import path from "node:path";
import { fileURLToPath } from "node:url";
import { scanProject } from "../scanner/index.ts";
import { loadLocalRegistry, findSkill, validateLocalRegistry } from "../registry/index.ts";
import { groupRecommendationsByLane, recommendSkills } from "../recommender/index.ts";
import { auditSkill } from "../audit/index.ts";
import { getAdapter } from "../installers/codex.ts";
import { readLockfile } from "../lockfile/index.ts";
import {
  loadFrontendEvalSuite,
  runFrontendRoutingEval,
  summarizeFrontendEvalSuite,
  validateFrontendEvalSuite,
} from "../evals/frontend.ts";
import { defaultRegistryRoot, packageRoot } from "../paths.ts";
import { skillLanes, type SkillLane } from "../types.ts";

type ParsedArgs = {
  command?: string;
  positionals: string[];
  flags: Record<string, string | boolean>;
};

const parseArgs = (argv: string[]): ParsedArgs => {
  const [command, ...rest] = argv;
  const positionals: string[] = [];
  const flags: Record<string, string | boolean> = {};

  for (let index = 0; index < rest.length; index += 1) {
    const arg = rest[index];
    if (arg.startsWith("--")) {
      const key = arg.slice(2);
      const next = rest[index + 1];
      if (!next || next.startsWith("--")) {
        flags[key] = true;
      } else {
        flags[key] = next;
        index += 1;
      }
    } else {
      positionals.push(arg);
    }
  }

  return { command, positionals, flags };
};

const asString = (value: string | boolean | undefined, fallback: string) => (typeof value === "string" ? value : fallback);

const asSkillLane = (value: string | boolean | undefined): SkillLane | undefined => {
  if (value === undefined) return undefined;
  if (typeof value === "string" && skillLanes.includes(value as SkillLane)) {
    return value as SkillLane;
  }
  throw new Error(`--lane must be one of ${skillLanes.join(", ")}.`);
};

const asPositiveInteger = (
  value: string | boolean | undefined,
  flagName: string,
): number | undefined => {
  if (value === undefined) return undefined;
  if (typeof value === "string") {
    const parsed = Number(value);
    if (Number.isInteger(parsed) && parsed >= 1) return parsed;
  }
  throw new Error(`${flagName} must be a positive integer.`);
};

const printJson = (value: unknown) => {
  console.log(JSON.stringify(value, null, 2));
};

const printHelp = () => {
  console.log(`skillranger

Usage:
  skillranger scan [project] [--json]
  skillranger recommend [project] [--target codex] [--intent "..."] [--lane <lane>] [--limit-per-lane <n>] [--explain] [--json]
  skillranger audit <skill-id> [--json]
  skillranger validate:registry [--json]
  skillranger audit:registry [--json]
  skillranger lint:skills [--json]
  skillranger publish:check [--json]
  skillranger eval:frontend [--suite <path>] [--json]
  skillranger eval:frontend --run-routing --project <path> [--target codex] [--suite <path>] [--json]
  skillranger install <skill-id> --project <path> [--target codex] [--scope repo] [--dry-run] [--yes]
  skillranger installed [project] [--project <path>] [--json]
  skillranger mcp
  skillranger doctor

Source-run equivalent from a checkout:
  node src/cli/index.ts <command> [...args]
`);
};

const runMode = () => {
  const entrypoint = process.argv[1] ?? "";
  const modulePath = fileURLToPath(import.meta.url);
  const candidates = [entrypoint, modulePath];
  if (candidates.some((candidate) => candidate.includes(`${path.sep}src${path.sep}`))) return "source-run";
  if (candidates.some((candidate) => candidate.includes(`${path.sep}dist${path.sep}`))) return "compiled-binary";
  return "unknown";
};

const formatScoreBreakdown = (recommendation: { scoreBreakdown: Record<string, number> }) => {
  const breakdown = recommendation.scoreBreakdown;
  return [
    `stack ${breakdown.stackMatch.toFixed(3)}`,
    `intent ${breakdown.userIntentMatch.toFixed(3)}`,
    `quality ${breakdown.qualityScore.toFixed(3)}`,
    `security ${breakdown.securityScore.toFixed(3)}`,
    `freshness ${breakdown.freshnessScore.toFixed(3)}`,
    `compatibility ${breakdown.compatibilityScore.toFixed(3)}`,
    `lane adj ${breakdown.laneAdjustment.toFixed(3)}`,
    `skill adj ${breakdown.skillAdjustment.toFixed(3)}`,
  ].join("; ");
};

const formatProjectPath = (projectRoot: string, filePath: string) => {
  const relativePath = path.relative(projectRoot, filePath);
  return relativePath && !relativePath.startsWith("..") ? relativePath : filePath;
};

const printInstallSummary = (
  plan: {
    skillId: string;
    targetAgent: string;
    scope: string;
    writes: string[];
    lockfileUpdates: string[];
    warnings: string[];
  },
  projectRoot: string,
  dryRun: boolean,
) => {
  console.log(dryRun ? `Install plan for ${plan.skillId}` : `Installed ${plan.skillId}`);
  console.log(`Target: ${plan.targetAgent}, scope ${plan.scope}`);
  console.log(dryRun ? "Would write:" : "Wrote:");
  for (const write of plan.writes) {
    console.log(`- ${formatProjectPath(projectRoot, write)}`);
  }
  console.log(dryRun ? "Would update:" : "Updated:");
  for (const update of plan.lockfileUpdates) {
    console.log(`- ${formatProjectPath(projectRoot, update)}`);
  }
  for (const warning of plan.warnings) {
    console.log(`Warning: ${warning}`);
  }
  if (dryRun) {
    console.log("Next: re-run with --yes to apply.");
    return;
  }
  const skillDir = plan.writes[0]
    ? path.dirname(formatProjectPath(projectRoot, plan.writes[0]))
    : ".agents/skills";
  console.log(`Use: start or reload ${plan.targetAgent} in this repo; the skill is available at ${skillDir}.`);
};

const run = async () => {
  const args = parseArgs(process.argv.slice(2));
  const command = args.command;
  const registryRoot = defaultRegistryRoot;

  if (!command || command === "help" || command === "--help") {
    printHelp();
    return;
  }

  if (command === "mcp") {
    const { startMcpServer } = await import("../mcp/server.ts");
    startMcpServer();
    return;
  }

  if (command === "scan") {
    const projectRoot = path.resolve(args.positionals[0] ?? ".");
    const fingerprint = await scanProject(projectRoot);
    if (args.flags.json) {
      printJson(fingerprint);
      return;
    }

    console.log(`Project: ${fingerprint.root}`);
    if (fingerprint.packageManager) {
      console.log(`Package manager: ${fingerprint.packageManager.name} (${fingerprint.packageManager.evidence.join(", ")})`);
    }
    console.log(`Types: ${fingerprint.projectTypes.map((type) => type.type).join(", ") || "unknown"}`);
    console.log(`Languages: ${fingerprint.languages.map((item) => item.name).join(", ") || "unknown"}`);
    console.log(`Frameworks: ${fingerprint.frameworks.map((item) => item.name).join(", ") || "none detected"}`);
    console.log(`Styling: ${fingerprint.styling.map((item) => item.name).join(", ") || "none detected"}`);
    console.log(`Testing: ${fingerprint.testing.map((item) => item.name).join(", ") || "none detected"}`);
    for (const warning of fingerprint.warnings) console.log(`Warning: ${warning}`);
    return;
  }

  if (command === "recommend") {
    const projectRoot = path.resolve(args.positionals[0] ?? ".");
    const targetAgent = asString(args.flags.target, "codex");
    const userIntent = typeof args.flags.intent === "string" ? args.flags.intent : undefined;
    const lane = asSkillLane(args.flags.lane);
    const limitPerLane = asPositiveInteger(args.flags["limit-per-lane"], "--limit-per-lane");
    const fingerprint = await scanProject(projectRoot);
    const skills = await loadLocalRegistry(registryRoot);
    const recommendations = recommendSkills(fingerprint, skills, { targetAgent, userIntent, lane, limitPerLane });
    if (args.flags.json) {
      printJson({ recommendations, recommendationGroups: groupRecommendationsByLane(recommendations) });
      return;
    }
    console.log(`Recommendations for ${targetAgent}:`);
    for (const group of groupRecommendationsByLane(recommendations)) {
      console.log(`\n${group.lane}:`);
      group.recommendations.forEach((recommendation, index) => {
        const category = recommendation.category ? `  ${recommendation.category}` : "";
        console.log(`${index + 1}. ${recommendation.skillId}${category}  score ${recommendation.score.toFixed(3)}  risk ${recommendation.riskLevel}`);
        console.log(`   ${recommendation.reasons.join("; ")}`);
        if (args.flags.explain) {
          console.log(`   score drivers: ${formatScoreBreakdown(recommendation)}`);
        }
      });
    }
    return;
  }

  if (command === "audit") {
    const skillId = args.positionals[0];
    if (!skillId) throw new Error("Missing skill id.");
    const skill = await findSkill(skillId, registryRoot);
    if (!skill) throw new Error(`Skill not found: ${skillId}`);
    const report = await auditSkill(skill);
    if (args.flags.json) {
      printJson(report);
      return;
    }
    console.log(`${report.skillId}: risk ${report.riskLevel}, security ${report.securityScore}, ${report.checksum}`);
    if (report.findings.length === 0) {
      console.log("No findings.");
    } else {
      for (const finding of report.findings) {
        console.log(`- [${finding.severity}] ${finding.code}${finding.path ? ` (${finding.path})` : ""}: ${finding.message}`);
      }
    }
    return;
  }

  if (command === "validate:registry" || command === "lint:skills") {
    const report = await validateLocalRegistry(registryRoot);
    if (args.flags.json) {
      printJson(report);
      return;
    }
    console.log(`Registry valid: ${report.skills.length} skills`);
    return;
  }

  if (command === "audit:registry" || command === "publish:check") {
    const validation = await validateLocalRegistry(registryRoot);
    const skills = await loadLocalRegistry(registryRoot);
    const reports = await Promise.all(skills.map((skill) => auditSkill(skill)));
    const failedReports = reports.filter((report) => report.riskLevel !== "low" || report.findings.length > 0);
    const report = {
      ok: failedReports.length === 0,
      validatedSkills: validation.skills.length,
      audits: reports
    };
    if (args.flags.json) {
      printJson(report);
    } else {
      console.log(`Registry audit: ${reports.length} skills, ${failedReports.length} failed`);
      for (const failed of failedReports) {
        console.log(`- ${failed.skillId}: risk ${failed.riskLevel}, findings ${failed.findings.length}`);
      }
    }
    if (!report.ok) {
      throw new Error("Registry audit failed.");
    }
    return;
  }

  if (command === "eval:frontend") {
    const suitePath = typeof args.flags.suite === "string" ? path.resolve(args.flags.suite) : undefined;
    const suite = await loadFrontendEvalSuite(suitePath);
    const issues = validateFrontendEvalSuite(suite);
    const runRouting = Boolean(args.flags["run-routing"]);
    const projectRoot = typeof args.flags.project === "string" ? path.resolve(args.flags.project) : undefined;
    const targetAgent = asString(args.flags.target, "codex");
    if (runRouting && !projectRoot) throw new Error("--project is required with --run-routing.");
    const routingEval = runRouting && projectRoot
      ? await runFrontendRoutingEval(suite, { projectRoot, targetAgent })
      : undefined;
    const report = {
      ok: issues.length === 0 && (!routingEval || routingEval.failures.length === 0),
      issues,
      summary: summarizeFrontendEvalSuite(suite),
      ...(routingEval ? { routingEval } : {})
    };
    if (args.flags.json) {
      printJson(report);
    } else {
      console.log(`Frontend eval suite: ${report.summary.name}`);
      console.log(`Trigger prompts: ${report.summary.triggerPrompts.total}/${report.summary.triggerPrompts.target} seeded`);
      console.log(`Task evals: ${report.summary.taskEvals.seedTasks}/${report.summary.taskEvals.target} seeded`);
      console.log(`Task bands: ${report.summary.taskEvals.bands.join(", ")}`);
      console.log(`Promotion gates: ${report.summary.promotionGates.join(", ")}`);
      if (routingEval) {
        console.log(`Routing eval: ${routingEval.metrics.passed}/${routingEval.metrics.evaluated} passed (${routingEval.metrics.overallPassRate.toFixed(3)})`);
        console.log(`Expected skill recall: ${routingEval.metrics.expectedSkillRecall.toFixed(3)}`);
        console.log(`Should-not-trigger specificity: ${routingEval.metrics.shouldNotTriggerSpecificity.toFixed(3)}`);
        for (const failure of routingEval.failures) {
          console.log(`Failure: ${failure.id} expected ${failure.expected}, received ${failure.actual ?? "none"} (${failure.reason})`);
        }
      }
      if (issues.length > 0) {
        for (const issue of issues) console.log(`Issue: ${issue}`);
      }
    }
    if (issues.length > 0) throw new Error("Frontend eval suite validation failed.");
    return;
  }

  if (command === "install") {
    const skillId = args.positionals[0];
    if (!skillId) throw new Error("Missing skill id.");
    const projectRoot = path.resolve(asString(args.flags.project, "."));
    const targetAgent = asString(args.flags.target, "codex");
    const scope = asString(args.flags.scope, "repo") as "repo" | "user";
    const dryRun = Boolean(args.flags["dry-run"]) || !args.flags.yes;
    const skill = await findSkill(skillId, registryRoot);
    if (!skill) throw new Error(`Skill not found: ${skillId}`);
    const adapter = getAdapter(targetAgent);
    const plan = dryRun
      ? await adapter.planInstall(skill, { projectRoot, targetAgent, scope, dryRun })
      : await adapter.applyInstall(skill, { projectRoot, targetAgent, scope, dryRun });
    if (args.flags.json) {
      printJson({ plan, nextStep: dryRun ? "Re-run with --yes to apply." : "Installed and locked." });
      return;
    }
    printInstallSummary(plan, projectRoot, dryRun);
    return;
  }

  if (command === "installed" || command === "list-installed") {
    const projectRoot = path.resolve(asString(args.flags.project, args.positionals[0] ?? "."));
    const lockfile = await readLockfile(projectRoot);
    if (args.flags.json) {
      printJson({ projectRoot, installed: lockfile.installed });
      return;
    }
    console.log(`Installed skills for ${projectRoot}:`);
    if (lockfile.installed.length === 0) {
      console.log("No skills installed.");
      return;
    }
    for (const entry of lockfile.installed) {
      console.log(`- ${entry.skillId}@${entry.version} -> ${entry.installedPath} (${entry.targetAgent}, ${entry.scope})`);
    }
    return;
  }

  if (command === "doctor") {
    const skills = await loadLocalRegistry(registryRoot);
    console.log(`Registry skills: ${skills.length}`);
    console.log(`Node: ${process.version}`);
    console.log(`Run mode: ${runMode()}`);
    console.log(`Package root: ${packageRoot}`);
    console.log(`Registry root: ${registryRoot}`);
    console.log("MVP adapters: codex, generic-agent-skills");
    return;
  }

  throw new Error(`Unknown command: ${command}`);
};

run().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
});
